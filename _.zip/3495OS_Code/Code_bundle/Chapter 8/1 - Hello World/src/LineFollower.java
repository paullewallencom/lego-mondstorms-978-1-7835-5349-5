public class LineFollower
{
    public static void main(String[] args)
    {
        log("Hello, World");
    }


    private static void log(String msg)
    {
        System.out.println("log>\t" + msg);
    }
}
