import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;

public class ColorSensor extends EV3ColorSensor
{
    public ColorSensor(Port port)
    {
        super(port);
    }
}
